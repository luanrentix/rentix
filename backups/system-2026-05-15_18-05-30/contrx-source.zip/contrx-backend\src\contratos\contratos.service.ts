import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  Contract,
  ContractStatus,
  FinancialAccountStatus,
  Prisma,
} from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CriarContratoDto } from './dto/criar-contrato.dto';
import { AtualizarContratoDto } from './dto/atualizar-contrato.dto';
import {
  MotivoContratoDto,
  RenovarContratoDto,
} from './dto/acoes-contrato.dto';

@Injectable()
export class ContratosService {
  constructor(private readonly prisma: PrismaService) {}

  async create(createContractDto: CriarContratoDto, companyId: string) {
    const data = {
      ...createContractDto,
      companyId,
    };

    await this.validateContractRelations(
      data.companyId,
      data.propertyId,
      data.tenantId,
    );

    await this.ensurePropertyHasNoActiveContract(
      data.companyId,
      data.propertyId,
    );

    return this.prisma.contract.create({
      data: this.buildCreateData(data),
      include: this.defaultInclude,
    });
  }

  async findAll(companyId?: string) {
    if (!companyId) {
      throw new BadRequestException('O companyId é obrigatório.');
    }

    return this.prisma.contract.findMany({
      where: { companyId },
      orderBy: { createdAt: 'desc' },
      include: this.defaultInclude,
    });
  }

  async findOne(id: string, companyId: string) {
    const contract = await this.prisma.contract.findFirst({
      where: { id, companyId },
      include: this.defaultInclude,
    });

    if (!contract) {
      throw new NotFoundException('Contrato nao encontrado.');
    }

    return contract;
  }

  async update(
    id: string,
    updateContractDto: AtualizarContratoDto,
    companyId: string,
  ) {
    const currentContract = await this.prisma.contract.findFirst({
      where: { id, companyId },
    });

    if (!currentContract) {
      throw new NotFoundException('Contrato nao encontrado.');
    }

    const nextCompanyId = companyId;
    const nextPropertyId =
      updateContractDto.propertyId ?? currentContract.propertyId;
    const nextTenantId = updateContractDto.tenantId ?? currentContract.tenantId;

    await this.validateCompany(nextCompanyId);

    if (
      nextPropertyId !== currentContract.propertyId ||
      nextTenantId !== currentContract.tenantId
    ) {
      await this.validateContractRelations(
        nextCompanyId,
        nextPropertyId,
        nextTenantId,
      );
    }

    if (
      nextPropertyId !== currentContract.propertyId ||
      nextCompanyId !== currentContract.companyId
    ) {
      await this.ensurePropertyHasNoActiveContract(
        nextCompanyId,
        nextPropertyId,
        currentContract.id,
      );
    }

    return this.prisma.contract.update({
      where: { id },
      data: this.buildUpdateData(updateContractDto),
      include: this.defaultInclude,
    });
  }

  async cancel(id: string, data: MotivoContratoDto, companyId: string) {
    const reason = this.normalizeRequiredReason(data.reason);
    await this.ensureContractExists(id, companyId);

    return this.prisma.$transaction(async (tx) => {
      await this.deletePendingReceivablesFromContract(tx, id, companyId);

      return tx.contract.update({
        where: { id },
        data: {
          status: ContractStatus.CANCELED,
          deletedAt: null,
          statusReason: reason,
          statusReasonType: 'CANCELED',
          statusReasonAt: new Date(),
        },
        include: this.defaultInclude,
      });
    });
  }

  async softDelete(id: string, data: MotivoContratoDto, companyId: string) {
    const reason = this.normalizeRequiredReason(data.reason);
    await this.ensureContractExists(id, companyId);

    return this.prisma.$transaction(async (tx) => {
      await this.deletePendingReceivablesFromContract(tx, id, companyId);

      return tx.contract.update({
        where: { id },
        data: {
          status: ContractStatus.DELETED,
          deletedAt: new Date(),
          statusReason: reason,
          statusReasonType: 'DELETED',
          statusReasonAt: new Date(),
        },
        include: this.defaultInclude,
      });
    });
  }

  async finish(id: string, data: MotivoContratoDto, companyId: string) {
    const reason = this.normalizeRequiredReason(data.reason);
    await this.ensureContractExists(id, companyId);

    return this.prisma.$transaction(async (tx) => {
      await this.deleteFuturePendingReceivablesFromContract(tx, id, companyId);

      return tx.contract.update({
        where: { id },
        data: {
          status: ContractStatus.FINISHED,
          finishedAt: new Date(),
          finishReason: reason,
          statusReason: reason,
          statusReasonType: null,
          statusReasonAt: new Date(),
        },
        include: this.defaultInclude,
      });
    });
  }

  async renew(id: string, data: RenovarContratoDto, companyId: string) {
    const currentContract = await this.ensureContractExists(id, companyId);
    const nextEndDate = this.parseDate(data.endDate, 'Data final invalida.');
    const nextRentValue = Number(data.rentValue || 0);

    if (nextEndDate <= currentContract.endDate) {
      throw new BadRequestException(
        'A nova data final precisa ser maior que a data final atual.',
      );
    }

    if (!Number.isFinite(nextRentValue) || nextRentValue <= 0) {
      throw new BadRequestException('Valor de aluguel invalido.');
    }

    const renewedAt = new Date();
    const renewalRecord = {
      renewedAt: renewedAt.toISOString(),
      previousEndDate: this.formatDateForInput(currentContract.endDate),
      newEndDate: this.formatDateForInput(nextEndDate),
      previousRentValue: Number(currentContract.rentValue || 0),
      newRentValue: nextRentValue,
      notes: data.notes?.trim() || undefined,
    };
    const renewalHistory = Array.isArray(currentContract.renewalHistory)
      ? currentContract.renewalHistory
      : [];

    return this.prisma.$transaction(async (tx) => {
      const renewedContract = await tx.contract.update({
        where: { id },
        data: {
          endDate: nextEndDate,
          rentValue: new Prisma.Decimal(nextRentValue),
          status: ContractStatus.ACTIVE,
          renewedAt,
          renewalHistory: [...renewalHistory, renewalRecord],
          finishedAt: null,
          finishReason: null,
        },
        include: this.defaultInclude,
      });

      await this.syncOpenReceivablesFromContract(tx, renewedContract);

      return renewedContract;
    });
  }

  async remove(id: string, companyId: string) {
    return this.softDelete(
      id,
      { reason: 'Contrato excluido pelo endpoint legado.' },
      companyId,
    );
  }

  private get defaultInclude() {
    return {
      property: true,
      tenant: true,
      company: true,
    };
  }

  private async ensureContractExists(id: string, companyId: string) {
    const contract = await this.prisma.contract.findFirst({
      where: { id, companyId },
    });

    if (!contract) {
      throw new NotFoundException('Contrato nao encontrado.');
    }

    return contract;
  }

  private async validateCompany(companyId: string) {
    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
      select: { id: true },
    });

    if (!company) {
      throw new BadRequestException('Empresa nao encontrada.');
    }
  }

  private normalizeRequiredReason(reason?: string | null) {
    const cleanReason = reason?.trim() || '';

    if (cleanReason.length < 5) {
      throw new BadRequestException(
        'Informe um motivo com pelo menos 5 caracteres.',
      );
    }

    return cleanReason;
  }

  private async deletePendingReceivablesFromContract(
    tx: Prisma.TransactionClient,
    contractId: string,
    companyId: string,
  ) {
    const pendingAccounts = await tx.contaReceber.findMany({
      where: {
        contractId,
        companyId,
        status: FinancialAccountStatus.PENDING,
      },
      select: { id: true },
    });
    const pendingAccountIds = pendingAccounts.map((account) => account.id);

    if (pendingAccountIds.length === 0) return;

    await tx.pagamentoRecebido.deleteMany({
      where: { chargeId: { in: pendingAccountIds } },
    });
    await tx.contaReceber.deleteMany({
      where: { id: { in: pendingAccountIds } },
    });
  }

  private async deleteFuturePendingReceivablesFromContract(
    tx: Prisma.TransactionClient,
    contractId: string,
    companyId: string,
  ) {
    const futureAccounts = await tx.contaReceber.findMany({
      where: {
        contractId,
        companyId,
        status: FinancialAccountStatus.PENDING,
        dueDate: { gte: this.getTodayStart() },
      },
      select: { id: true },
    });
    const futureAccountIds = futureAccounts.map((account) => account.id);

    if (futureAccountIds.length === 0) return;

    await tx.pagamentoRecebido.deleteMany({
      where: { chargeId: { in: futureAccountIds } },
    });
    await tx.contaReceber.deleteMany({
      where: { id: { in: futureAccountIds } },
    });
  }

  private async syncOpenReceivablesFromContract(
    tx: Prisma.TransactionClient,
    contract: Contract,
  ) {
    const receivableSchedule = this.getContractReceivableSchedule(contract);
    const linkedAccounts = await tx.contaReceber.findMany({
      where: {
        contractId: contract.id,
        companyId: contract.companyId,
      },
      orderBy: { installmentNumber: 'asc' },
    });
    const paidAccounts = linkedAccounts.filter(
      (account) => account.status === FinancialAccountStatus.PAID,
    );
    const openAccounts = linkedAccounts.filter(
      (account) => account.status !== FinancialAccountStatus.PAID,
    );
    const openReceivableSchedule = receivableSchedule.slice(
      paidAccounts.length,
    );
    const installmentGroupId = `${contract.id}-installments`;

    await Promise.all(
      openAccounts
        .slice(0, openReceivableSchedule.length)
        .map((account, index) => {
          const installment = openReceivableSchedule[index];

          return tx.contaReceber.update({
            where: { id: account.id },
            data: {
              tenant: { connect: { id: contract.tenantId } },
              propertyName: contract.propertyName || '',
              tenantName: contract.tenantName || '',
              issueDate: contract.startDate,
              dueDate: installment.dueDate,
              amount: new Prisma.Decimal(installment.amount),
              manual: false,
              installmentNumber: installment.installmentNumber,
              installmentTotal: installment.installmentTotal,
              installmentGroupId,
              isDownPayment: false,
            },
          });
        }),
    );

    const extraOpenAccounts = openAccounts.slice(openReceivableSchedule.length);
    const extraOpenAccountIds = extraOpenAccounts.map((account) => account.id);

    if (extraOpenAccountIds.length > 0) {
      await tx.pagamentoRecebido.deleteMany({
        where: { chargeId: { in: extraOpenAccountIds } },
      });
      await tx.contaReceber.deleteMany({
        where: { id: { in: extraOpenAccountIds } },
      });
    }

    const missingSchedule = openReceivableSchedule.slice(openAccounts.length);

    await Promise.all(
      missingSchedule.map((installment) =>
        tx.contaReceber.create({
          data: {
            company: { connect: { id: contract.companyId } },
            contract: { connect: { id: contract.id } },
            tenant: { connect: { id: contract.tenantId } },
            propertyName: contract.propertyName || '',
            tenantName: contract.tenantName || '',
            issueDate: contract.startDate,
            dueDate: installment.dueDate,
            amount: new Prisma.Decimal(installment.amount),
            status: FinancialAccountStatus.PENDING,
            manual: false,
            installmentNumber: installment.installmentNumber,
            installmentTotal: installment.installmentTotal,
            installmentGroupId,
            isDownPayment: false,
          },
        }),
      ),
    );
  }

  private getContractReceivableSchedule(contract: Contract) {
    if (contract.isTemporaryRental) {
      return [
        {
          dueDate: contract.startDate,
          amount: Number(contract.rentValue || 0),
          installmentNumber: 1,
          installmentTotal: 1,
        },
      ];
    }

    const installmentQuantity = this.getContractInstallmentQuantity(
      contract.startDate,
      contract.endDate,
    );

    return Array.from({ length: installmentQuantity }, (_, index) => ({
      dueDate: this.addMonthsToDate(contract.startDate, index),
      amount: Number(contract.rentValue || 0),
      installmentNumber: index + 1,
      installmentTotal: installmentQuantity,
    }));
  }

  private getContractInstallmentQuantity(startDate: Date, endDate: Date) {
    const monthDifference =
      (endDate.getFullYear() - startDate.getFullYear()) * 12 +
      endDate.getMonth() -
      startDate.getMonth() +
      1;

    return Math.max(monthDifference, 1);
  }

  private addMonthsToDate(date: Date, monthsToAdd: number) {
    const nextDate = new Date(date);

    nextDate.setMonth(nextDate.getMonth() + monthsToAdd);

    return nextDate;
  }

  private async validateContractRelations(
    companyId: string,
    propertyId: string,
    tenantId: string,
  ) {
    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
    });

    if (!company) {
      throw new BadRequestException('Empresa nao encontrada.');
    }

    const property = await this.prisma.property.findFirst({
      where: {
        id: propertyId,
        companyId,
      },
    });

    if (!property) {
      throw new BadRequestException('Imovel nao encontrado.');
    }

    if (!property.isActive) {
      throw new BadRequestException('Imovel inativo nao pode ser alugado.');
    }

    const tenant = await this.prisma.person.findFirst({
      where: {
        id: tenantId,
        companyId,
      },
    });

    if (!tenant) {
      throw new BadRequestException('Inquilino nao encontrado.');
    }

    if (tenant.status !== 'ACTIVE') {
      throw new BadRequestException('Inquilino inativo nao pode ser usado.');
    }
  }

  private async ensurePropertyHasNoActiveContract(
    companyId: string,
    propertyId: string,
    ignoredContractId?: string,
  ) {
    const existingContract = await this.prisma.contract.findFirst({
      where: {
        companyId,
        propertyId,
        status: {
          in: [ContractStatus.ACTIVE],
        },
        endDate: {
          gte: this.getTodayStart(),
        },
        id: ignoredContractId ? { not: ignoredContractId } : undefined,
      },
    });

    if (existingContract) {
      throw new BadRequestException('Este imovel ja possui contrato ativo.');
    }
  }

  private buildCreateData(
    createContractDto: CriarContratoDto,
  ): Prisma.ContractCreateInput {
    return {
      company: { connect: { id: createContractDto.companyId } },
      property: { connect: { id: createContractDto.propertyId } },
      tenant: { connect: { id: createContractDto.tenantId } },
      propertyName: createContractDto.propertyName || null,
      tenantName: createContractDto.tenantName || null,
      startDate: this.parseDate(
        createContractDto.startDate,
        'Data inicial invalida.',
      ),
      endDate: this.parseDate(
        createContractDto.endDate,
        'Data final invalida.',
      ),
      rentValue: new Prisma.Decimal(createContractDto.rentValue),
      status: createContractDto.status ?? ContractStatus.ACTIVE,
      deletedAt: this.parseOptionalDate(createContractDto.deletedAt),
      statusReason: createContractDto.statusReason || null,
      statusReasonType: createContractDto.statusReasonType ?? null,
      statusReasonAt: this.parseOptionalDate(createContractDto.statusReasonAt),
      isTemporaryRental: createContractDto.isTemporaryRental ?? false,
      checkInTime: createContractDto.checkInTime || null,
      checkOutTime: createContractDto.checkOutTime || null,
      renewedAt: this.parseOptionalDate(createContractDto.renewedAt),
      renewalHistory:
        createContractDto.renewalHistory === undefined
          ? Prisma.JsonNull
          : createContractDto.renewalHistory,
      finishedAt: this.parseOptionalDate(createContractDto.finishedAt),
      finishReason: createContractDto.finishReason || null,
    };
  }

  private buildUpdateData(
    updateContractDto: AtualizarContratoDto,
  ): Prisma.ContractUpdateInput {
    return {
      property: updateContractDto.propertyId
        ? { connect: { id: updateContractDto.propertyId } }
        : undefined,
      tenant: updateContractDto.tenantId
        ? { connect: { id: updateContractDto.tenantId } }
        : undefined,
      propertyName:
        updateContractDto.propertyName !== undefined
          ? updateContractDto.propertyName || null
          : undefined,
      tenantName:
        updateContractDto.tenantName !== undefined
          ? updateContractDto.tenantName || null
          : undefined,
      startDate:
        updateContractDto.startDate !== undefined
          ? this.parseDate(
              updateContractDto.startDate,
              'Data inicial invalida.',
            )
          : undefined,
      endDate:
        updateContractDto.endDate !== undefined
          ? this.parseDate(updateContractDto.endDate, 'Data final invalida.')
          : undefined,
      rentValue:
        updateContractDto.rentValue !== undefined
          ? new Prisma.Decimal(updateContractDto.rentValue)
          : undefined,
      status: updateContractDto.status,
      deletedAt:
        updateContractDto.deletedAt !== undefined
          ? this.parseOptionalDate(updateContractDto.deletedAt)
          : undefined,
      statusReason:
        updateContractDto.statusReason !== undefined
          ? updateContractDto.statusReason || null
          : undefined,
      statusReasonType:
        updateContractDto.statusReasonType !== undefined
          ? updateContractDto.statusReasonType
          : undefined,
      statusReasonAt:
        updateContractDto.statusReasonAt !== undefined
          ? this.parseOptionalDate(updateContractDto.statusReasonAt)
          : undefined,
      isTemporaryRental: updateContractDto.isTemporaryRental,
      checkInTime:
        updateContractDto.checkInTime !== undefined
          ? updateContractDto.checkInTime || null
          : undefined,
      checkOutTime:
        updateContractDto.checkOutTime !== undefined
          ? updateContractDto.checkOutTime || null
          : undefined,
      renewedAt:
        updateContractDto.renewedAt !== undefined
          ? this.parseOptionalDate(updateContractDto.renewedAt)
          : undefined,
      renewalHistory:
        updateContractDto.renewalHistory !== undefined
          ? updateContractDto.renewalHistory
          : undefined,
      finishedAt:
        updateContractDto.finishedAt !== undefined
          ? this.parseOptionalDate(updateContractDto.finishedAt)
          : undefined,
      finishReason:
        updateContractDto.finishReason !== undefined
          ? updateContractDto.finishReason || null
          : undefined,
    };
  }

  private parseDate(value: string, errorMessage: string) {
    const parsedDate = new Date(`${value}T00:00:00`);

    if (Number.isNaN(parsedDate.getTime())) {
      throw new BadRequestException(errorMessage);
    }

    return parsedDate;
  }

  private parseOptionalDate(value?: string | null) {
    if (!value) return null;

    const parsedDate = new Date(value);

    if (Number.isNaN(parsedDate.getTime())) {
      throw new BadRequestException('Data invalida.');
    }

    return parsedDate;
  }

  private formatDateForInput(value: Date) {
    const year = value.getFullYear();
    const month = String(value.getMonth() + 1).padStart(2, '0');
    const day = String(value.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  private getTodayStart() {
    const today = new Date();

    today.setHours(0, 0, 0, 0);

    return today;
  }
}
